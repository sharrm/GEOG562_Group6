#################################################
# Geog 462/562 Group 6 Final Project
# Absolute Bathymetry from Satellite Derrived Bathymetry (relative) and Satellite Lidar using ICESAT and
# Sentinal/Landsat imagery

# Identify user defined function files
import SDB_Functions as sdb
import linear_regression as slr

#######################################################
# Step 1: Mask the land pixels from the imagery data

# Identify the input files
maskSHP = r"G:\My Drive\OSU Work\Geog 462 GIS III Analysis and Programing\Final Project\Other\clipper.shp" # in_shp
# in_raster = r"P:\SDB\Florida Keys\Popcorn\Test_Files\rel_test.tif"
blueInput = r"G:\My Drive\OSU Work\Geog 462 GIS III Analysis and Programing\NewFinal\Sentinel2\S2A_MSI_2021_12_01_16_05_11_T17RNH_rhos_492.tif"
greenInput = r"G:\My Drive\OSU Work\Geog 462 GIS III Analysis and Programing\NewFinal\Sentinel2\S2A_MSI_2021_12_01_16_05_11_T17RNH_rhos_560.tif"
redInput = r"G:\My Drive\OSU Work\Geog 462 GIS III Analysis and Programing\NewFinal\Sentinel2\S2A_MSI_2021_12_01_16_05_11_T17RNH_rhos_665.tif"

maskOutput = sdb.mask_imagery(redInput, greenInput, blueInput, maskSHP)

if maskOutput[0]:
    maskFilesList = maskOutput[1]
    print(f"The masked files are:\n"
          f"{maskFilesList[0]}\n"
          f"{maskFilesList[1]}\n"
          f"{maskFilesList[2]}\n")

    maskedBlue = maskFilesList[0]
    maskedGreen = maskFilesList[1]
    maskedRed = maskFilesList[2]
else:
    print("No masked files were returned from the file masking function.")


############################
# Step 2 Ratios

# Start with Green SDB (deeper)
green_SDB_output = sdb.pSDBgreen (maskedBlue, maskedGreen, maskSHP)

if green_SDB_output[0]:
    greenSDB = green_SDB_output[1]
else:
    print("No green SDB raster dataset was returned from the pSDBgreen function.")

# # Next do Red SDB (shallower)
# red_SDB_output = sdb.pSDBgreen (maskedBlue, maskedRed)
#
# if red_SDB_output[0]:
#     redSDB = red_SDB_output[1]
# else:
#     print("No green SDB raster dataset was returned from the pSDBgreen function.")


##############################
# Step 3 SLR

# Identify the ICESAT lidar dataset
icesat2 = r"G:\My Drive\OSU Work\Geog 462 GIS III Analysis and Programing\Final Project\ICESat2\icesat2_clipped.csv"

# Starting with the Green band:
# Identify other parameters
SDBraster = greenSDB
col = "green"
loc = "Key_Largo_Florida"

# Run the function to see the relationship between lidar depth and relative bathymetric depths
# (returns b0 and b1 as a tuple)
greenSLRcoefs = slr.slr(SDBraster, icesat2, col)



# # Red band next:
# # Identify other parameters
# SDBraster = redSDB
# col = "green"
# loc = "Key_Largo_Florida"
#
# # Run the function to see the relationship between lidar depth and relative bathymetric depths
# # (returns b0 and b1 as a tuple)
# greenSLR = slr(SDBraster, icesat2, col)




# # Next the Red Band:
# # Identify other parameters
# SDBraster = redSDB
# col = "red"
# loc = "Key_Largo_Florida"




################################
# Step 4 Apply SLR to relative bath

# Only green functionality is currently modeled
SDBraster = greenSDB
col = 'green'
loc = "Key_Largo_Florida"

final_raster = slr.bathy_from_slr(SDBraster, greenSLRcoefs, col, loc)

if final_raster[0]:
    print(f"The final raster is located at: {final_raster}")
else:
    print("Something went wrong with creating the lidar-based SDB raster.")