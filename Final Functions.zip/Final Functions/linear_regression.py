import rasterio
import pandas as pd
from sklearn.linear_model import LinearRegression
import matplotlib.pyplot as plt


# if __name__ == "__main__":

def slr(in_raster, icesat2, color):
    # Load in our CSVs

    pts = pd.read_csv(icesat2)

    coords = [(x, y) for x, y in zip(pts.E, pts.N)]

    # print(coords)

    # Define a path to the raster
    # in_raster = r"R:\GEOG562\Students\sharrm\Final\Data\Sentinel2\S2A_MSI_2021_12_01_16_05_11_T17RNH_rhos_492.tif"

    src = rasterio.open(in_raster)

    # sampled = rasterio.sample.sample_gen(in_raster, coords)

    pts['Raster Value'] = [x[0] for x in src.sample(coords)]

    X = pts.drop(columns=['E', 'N', 'Z'])
    y = pts.Z

    reg = LinearRegression().fit(X, y)
    r2 = reg.score(X, y)
    b1 = reg.coef_
    b0 = reg.intercept_
    print(f"The r-squared value is: {r2}")
    print(f"The m0 value is: {b0}")
    print(f"The m1 value is: {b1}")

    pts['y_hat'] = reg.predict(X)

    # plt.scatter(pts.Z, pts.y_hat, alpha=0.5)

    plt.plot(y, pts.y_hat, '.')
    # plt.plot(b0 + b1*X, '-')
    plt.title('ICESat-2 vs pSDB')
    plt.xlabel(f'{color} pSDB')
    plt.ylabel('ICESat-2')
    plt.show()

    # src = None
    # icesat2 = None

    # Create a tuple for return
    coefs = (b0, b1)
    return coefs


# read and write a new raster file using the coefficients from SLR
def bathy_from_slr(in_raster, coefsB0B1, color, location):
    # identify the coefficients
    b0 = coefsB0B1[0]
    b1 = coefsB0B1[1]

    # # read in the raster
    # src = rasterio.open(in_raster)
    # src = src.read(1)
    # # Extract metadata
    # out_meta = src.meta

    # Capture the metadata and create an array from the raster file
    with rasterio.open(in_raster) as src:
        out_meta = src.meta
        rastArray = src.read(1)

    # Based on the input color, conduct a raster math operation on the array to apply slr coefficients to relative
    # bathymetry
    match color:
        case "green":
            true_bath = -1*(b1 * rastArray + b0)

        case "red": # Reserved for future use
            true_bath = -1*(b1 * rastArray + b0)

        case "intermediate": # Reserved for future use
            print(f"{color} is not yet functional.")
            return False, None

    path = r"G:\My Drive\OSU Work\Geog 462 GIS III Analysis and Programing\NewFinal"
    outraster_name = f"{path}//{location}_SLR_bathymetry{color}.tif"
    with rasterio.open(outraster_name, "w", **out_meta) as dest:
        dest.write(true_bath, 1)

    return True, outraster_name

# rol = r"P:\SDB\Florida Keys\Popcorn\Test_Files\ratio_of_logs.tif"
#
# slr(rol)